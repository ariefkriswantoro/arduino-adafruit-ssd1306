#include <stdbool.h>

bool mgos_arduino_adafruit_ssd1306_init(void) {
  return true;
}
